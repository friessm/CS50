/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>
#include <stdio.h>

#include "helpers.h"

/**
 * Returns true if value is in array of n values, else false.
 */


int binary(int p_key, int p_array[], int p_min, int p_max)
{
    int mid;
    
    if (p_max < p_min)
    {
        return false;
    }
    else
    {
        mid = (p_min + p_max) / 2;
        
        if (p_array[mid] == p_key)
            return true;
        else if (p_array[mid] > p_key)
            return binary(p_key, p_array, p_min, mid - 1);
        else if (p_array[mid] < p_key)
            return binary(p_key, p_array, mid + 1, p_max);
        else
            return false;
    }
}


bool search(int value, int values[], int n)
{
    if (binary(value, values, 0, n) == true)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement an O(n^2) sorting algorithm

    int temp;
    
    // swap counter
    int count = -1;
    
    // bubble sort
    while (count != 0)
    {
        // reset swap counter to 0
        count = 0;
        
        // loop through array
        for (int i = 0; i < n - 1; i++)
        {
            if (values[i] > values[i + 1])
            {
                temp = values[i];
                values[i] = values[i + 1];
                values[i + 1] = temp;
                // add one to swap counter
                count = count + 1;
            }
        }
    }
    return;
}