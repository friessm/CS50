/**
 * fifteen.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Implements Game of Fifteen (generalized to d x d).
 *
 * Usage: fifteen d
 *
 * whereby the board's dimensions are to be d x d,
 * where d must be in [DIM_MIN,DIM_MAX]
 *
 * Note that usleep is obsolete, but it offers more granularity than
 * sleep and is simpler to use than nanosleep; `man usleep` for more.
 */
 
#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// constants
#define DIM_MIN 3
#define DIM_MAX 9

// board
int board[DIM_MAX][DIM_MAX];

// tracking empty
int x, y;

// dimensions
int d;

// prototypes
void clear(void);
void greet(void);
void init(void);
void draw(void);
bool move(int tile);
bool won(void);

int main(int argc, string argv[])
{
    // ensure proper usage
    if (argc != 2)
    {
        printf("Usage: fifteen d\n");
        return 1;
    }

    // ensure valid dimensions
    d = atoi(argv[1]);
    
    // if d is out of the range set by DIM_MIN and DIM_MAX prompt the user again
    if (d < DIM_MIN || d > DIM_MAX)
    {
        printf("Board must be between %i x %i and %i x %i, inclusive.\n",
            DIM_MIN, DIM_MIN, DIM_MAX, DIM_MAX);
        return 2;
    }
    
    // initiating variables for track-keeping of 0
    x = d - 1;
    y = d - 1;
        
    // open log
    FILE* file = fopen("log.txt", "w");
    if (file == NULL)
    {
        return 3;
    }

    // greet user with instructions
    greet();

    // initialize the board
    init();

    // accept moves until game is won
    while (true)
    {
        // clear the screen
        clear();

        // draw the current state of the board
        draw();

        // log the current state of the board (for testing)
        for (int i = 0; i < d; i++)
        {
            for (int j = 0; j < d; j++)
            {
                fprintf(file, "%i", board[i][j]);
                if (j < d - 1)
                {
                    fprintf(file, "|");
                }
            }
            fprintf(file, "\n");
        }
        fflush(file);

        // check for win
        if (won())
        {
            printf("ftw!\n");
            break;
        }

        // prompt for move
        printf("Tile to move: ");
        int tile = GetInt();
        
        // quit if user inputs 0 (for testing)
        if (tile == 0)
        {
            break;
        }

        // log move (for testing)
        fprintf(file, "%i\n", tile);
        fflush(file);

        // move if possible, else report illegality
        if (!move(tile))
        {
            printf("\nIllegal move.\n");
            usleep(500000);
        }

        // sleep thread for animation's sake
        usleep(500000);
    }
    
    // close log
    fclose(file);

    // success
    return 0;
}

/**
 * Clears screen using ANSI escape sequences.
 */
void clear(void)
{
    printf("\033[2J");
    printf("\033[%d;%dH", 0, 0);
}

/**
 * Greets player.
 */
void greet(void)
{
    clear();
    printf("WELCOME TO GAME OF FIFTEEN\n");
    usleep(2000000);
}

/**
 * Initializes the game's board with tiles numbered 1 through d*d - 1
 * (i.e., fills 2D array with values but does not actually print them).  
 */
void init(void)
{
    // TODO
    
    // order array elements in descending order

    int order[d * d];

    for (int i = 0; i < (d*d); i++)
    {
            // order the last three elements as follows: [1] [2] [0]
            if (d % 3 != 0 && i == d * d - 3) 
            {
                order[i] = 1;
                order[i + 1] = 2; 
                order[i + 2] = 0;
                break;
            }
            // order the elements of the array in descending order
            order[i] = ((d*d) - 1) - i;
    }
    
    // initialise 2d-array
    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            // allocate the elements of the one-dimensional to the 2d-array
            board[i][j] = order[i * d + j];
        }
    }
    return;
}

/**
 * Prints the board in its current state.
 */
void draw()
{
    // TODO

    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            if (board[i][j] > 0)
            {
               printf("| %d ", board[i][j]); 
            }
            if (board[i][j] == 0)
            {
                printf("| _ ");
            }
        
        }
        printf("\n");
    }
}

/**
 * If tile borders empty space, moves tile and returns true, else
 * returns false. 
 */
bool move(int tile)
{
    // TODO

    // int empty = board[x][y];
    int temp =  0;

    // iterate over board until the value of 'tile' is found
    // iterate through rows to find tile
    for (int i = 0; i < d; i++)
    {
        // iterate through columns to find tile
        for (int j = 0; j < d; j++)
        {
            if (tile == board[i][j])
            {
                // check if tile to move borders empty; if yes flip values and update x and y
                // move empty left
                if (board[i][j + 1] == board[x][y] && j + 1 < d) 
                {
                    temp = board[x][y];
                    board[x][y] = board[i][j];
                    board[i][j] = temp; 
                    x = i;
                    y = j;
                    return true;
                }
                // move empty up
                else if (board[i + 1][j] == board[x][y] && i + 1 < d) 
                {
                    temp = board[x][y];
                    board[x][y] = board[i][j];
                    board[i][j] = temp;
                    x = i;
                    y = j;
                    return true;
                }
                // move empty right
                else if (board[i][j - 1] == board[x][y] && j - 1 >= 0) 
                {
                    temp = board[x][y];
                    board[x][y] = board[i][j];
                    board[i][j] = temp; 
                    x = i;
                    y = j;
                    return true;
                }
                // move empty down
                else if (board[i - 1][j] == board[x][y] && i - 1 >= 0) 
                {
                    temp = board[x][y];
                    board[x][y] = board[i][j];
                    board[i][j] = temp; 
                    x = i;
                    y = j;
                    return true;
                }
            }
        }
    }
    return false;
}

/**
 * Returns true if game is won (i.e., board is in winning configuration), 
 * else false.
 */
bool won(void)
{
    // TODO
    // initiate won variable
    int w = 0;
    // initiate board size variable
    int b = d * d;
    
    // iterate through rows
    for (int i = 0; i < d; i++)
    {
        // iterate through columns
        for (int j = 0; j < d; j++)
        {
            // create counter
            w = w + 1;

            // if any tile != counter, return false, check next, if none are false return true
            if (board[i][j] != w && w <= b - 1)
            {
                return false;
            }
        }
    }
    // all tiles count up from 1
    printf("ftw \n");
    return true;
}